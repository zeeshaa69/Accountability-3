(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[185],{371:function(e,t,a){Promise.resolve().then(a.t.bind(a,8877,23)),Promise.resolve().then(a.bind(a,3372))},3372:function(e,t,a){"use strict";a.d(t,{default:function(){return x}});var r=a(7437),s=a(7138),n=a(6463),i=a(8030);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let c=(0,i.Z)("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);var l=a(1240),h=a(6273);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let d=(0,i.Z)("BarChart3",[["path",{d:"M3 3v18h18",key:"1s2lah"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);var o=a(7164);/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let u=(0,i.Z)("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]),y=[{href:"/",label:"Dashboard",icon:c},{href:"/clients",label:"Clients",icon:l.Z},{href:"/log",label:"Log Entry",icon:h.Z},{href:"/summary",label:"Monthly Report",icon:d},{href:"/export",label:"Export Excel",icon:o.Z}];function x(){let e=(0,n.usePathname)();return(0,r.jsxs)("aside",{className:"w-60 bg-white border-r border-gray-200 flex flex-col shrink-0",children:[(0,r.jsx)("div",{className:"px-5 py-5 border-b border-gray-100",children:(0,r.jsxs)("div",{className:"flex items-center gap-2.5",children:[(0,r.jsx)("div",{className:"w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center",children:(0,r.jsx)(u,{size:16,className:"text-white"})}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm font-700 text-gray-900 leading-tight font-semibold",children:"Accountability"}),(0,r.jsx)("p",{className:"text-xs text-gray-400 leading-tight",children:"Content Agency"})]})]})}),(0,r.jsx)("nav",{className:"flex-1 px-3 py-4 space-y-0.5",children:y.map(t=>{let{href:a,label:n,icon:i}=t,c=e===a;return(0,r.jsxs)(s.default,{href:a,className:"sidebar-link ".concat(c?"active":""),children:[(0,r.jsx)(i,{size:17}),n]},a)})}),(0,r.jsxs)("div",{className:"px-4 py-4 border-t border-gray-100",children:[(0,r.jsx)("p",{className:"text-xs text-gray-400",children:"Admin Dashboard"}),(0,r.jsx)("p",{className:"text-xs text-gray-300 mt-0.5",children:"v1.0 \xb7 Local storage"})]})]})}},6273:function(e,t,a){"use strict";a.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("CirclePlus",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 12h8",key:"1wcyev"}],["path",{d:"M12 8v8",key:"napkw2"}]])},7164:function(e,t,a){"use strict";a.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},1240:function(e,t,a){"use strict";a.d(t,{Z:function(){return r}});/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,a(8030).Z)("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]])},6463:function(e,t,a){"use strict";var r=a(1169);a.o(r,"useParams")&&a.d(t,{useParams:function(){return r.useParams}}),a.o(r,"usePathname")&&a.d(t,{usePathname:function(){return r.usePathname}}),a.o(r,"useRouter")&&a.d(t,{useRouter:function(){return r.useRouter}}),a.o(r,"useSearchParams")&&a.d(t,{useSearchParams:function(){return r.useSearchParams}})},8877:function(){}},function(e){e.O(0,[404,48,971,23,744],function(){return e(e.s=371)}),_N_E=e.O()}]);